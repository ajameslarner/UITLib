﻿using UITestingFramework.Utilities;

namespace UITestingFramework
{
    internal class $safeitemname$ : ITester
    {
        [UITestMethod]
        void UnitOfWork_InitialCondition_ExpectedResult()
        {
            //Setup

            //Sequence

            //Settle
            Settle.IsTrue(true);
        }
    }
}