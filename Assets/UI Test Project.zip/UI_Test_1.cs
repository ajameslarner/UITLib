﻿using UITestingFramework.Utilities;

namespace UITestingFramework
{
    internal class UI_Test_1 : ITester
    {
        [UITestMethod]
        void UnitOfWork_InitialCondition_ExpectedResult()
        {
            //Setup

            //Sequence

            //Settle
            Settle.IsTrue(true);
        }
    }
}